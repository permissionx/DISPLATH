#!/usr/bin/python3
from std_simulation import *
if __name__ == '__main__':
    myprocess = MySimulation()